INSERT INTO tb_produto_loja (produto_id, loja_id) VALUES
    (1, 1),
    (1, 3),
    (2, 1),
    (2, 4),
    (3, 2),
    (4, 2),
    (5, 2);