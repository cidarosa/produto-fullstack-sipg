INSERT INTO tb_produto (nome, descricao, valor, categoria_id) VALUES
    ('Mouse Microsoft', 'Mouse sem fio', 250.0, 5),
    ('Smartphone Samsung Galaxy A54 5G', 'Samsung Galaxy A54 5G', 1799.0, 1),
    ('Smart TV', 'Smart TV LG LED 65 polegadas', 3999, 2),
    ('Teclado Microsof', 'Teclado sem fio', 278.50, 6),
    ('Apple iPhone 15', 'Apple iPhone 15, 128G, Preto', 4999.00, 1);